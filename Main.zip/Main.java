package br.edu.fatecpg.tecprog.principal;
import br.edu.fatecpg.tecprog.classe.*;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		double valor;
		String nome;
		int numero;
		double saldo;
		
		System.out.println("Digite o nome :");
		nome = scan.nextLine();
		
		System.out.println("Digite o numero da conta: ");
		numero = scan.nextInt();
		
		
		System.out.println("Digite o tipo da conta:"
					+ "1- Corrente "
					+ "2- Poupança");
			int tipoconta = scan.nextInt();
						
			Conta conta = null;
			
			if(tipoconta == 1) {
					conta = new Corrente(nome, numero, 0);
					 
					} else if(tipoconta==2) {
						 conta =  new Poupanca(nome, numero, 0);
					
					} else {
						System.out.println("Conta inválida!");
					}
					
			boolean	i=true;
			while(i==true) {
			System.out.println("O que deseja fazer? "
	                + "1- Ver saldo "
	                + "2- Depositar "
	                + "3- Sacar "
	                + "4- Transferir "
	                + "5- Sair");
			
			int acao = scan.nextInt();
			
			switch(acao) {
			case 1:
				System.out.println(conta.getSaldo());
				break;
			case 2:
				System.out.println("Quanto deseja depositar: ");
				valor = scan.nextDouble();
				conta.setDepositar(valor);
				break;
			case 3:
				System.out.println("Quanto deseja sacar: ");
				valor = scan.nextDouble();
				conta.setSacar(valor);
				break;
			case 4:
				System.out.println("Quanto deseja transferir: ");
				valor = scan.nextDouble();
				System.out.println("Para que conta deseja tranferir: ");
				int num = scan.nextInt();
				conta.setTransferir(valor,num);
				break;
			case 5:
				i=false;
				break;
			}
			
		}
		
			
			
			scan.close();

		}
	}
		
	


