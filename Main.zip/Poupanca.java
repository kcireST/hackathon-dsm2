package br.edu.fatecpg.tecprog.classe;

public class Poupanca extends Conta{
	
	public Poupanca(String titular, int numero, double saldo) {
		super(titular, numero, saldo);
       
	}
	
	private void Sacar(double valor) {
			System.out.println("Não é possível sacar por ser uma conta poupança");

		}
	

	public void setSacar(double valor) {
	Sacar(valor);
		
	}


	public void setTransferir(double valor, int numero) {
		Transferir(valor,numero);
		
	}


	private void Transferir(double valor,int numero) {
		System.out.println("Não é possível transferir por ser uma conta poupança");

	}


}
