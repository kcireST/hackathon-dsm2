package br.edu.fatecpg.tecprog.classe;

public class Corrente extends Conta{

	public Corrente(String titular, int numero, double saldo) {
		super(titular, numero, saldo);
		
	}
	
}
