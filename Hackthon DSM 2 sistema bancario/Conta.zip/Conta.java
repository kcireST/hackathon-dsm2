package br.edu.fatecpg.tecprog.classe;

public abstract class Conta {

private double saldo;
public String titular;
public int numero;

public Conta(String titular, int numero, double saldo) {
	this.titular=titular;
	this.numero=numero;
	this.saldo=saldo;
	
}


public String getNome(){
	return this.titular;
}

public void setNome(String titular) {
	this.titular = titular;
}

public int getNumeroConta(){
	return this.numero;
}

public void setNumeroConta(int numero) {
	this.numero = numero;
}
public double getSaldo() {
	return this.saldo;
}
public void setSaldo(double saldo) {
	this.saldo = saldo;

}

private void Depositar(double valor) {
	setSaldo(this.getSaldo()+valor);
	System.out.println("O seu saldo é: R$"+getSaldo());
	
}

public void setDepositar(double valor) {
Depositar(valor);
	
}

private void Sacar(double valor) {
	if(valor<=this.getSaldo()) {
		this.setSaldo(this.getSaldo() - valor);
		System.out.println("O seu saldo restante é: R$"+getSaldo());
	}else {
		System.out.println("O seu saque não pode ser maior que o saldo atual");

	}
}

public void setSacar(double valor) {
Sacar(valor);
	
}


public void setTransferir(double valor, int numero) {
	Transferir(valor,numero);
	
}


private void Transferir(double valor,int numero) {
	if(valor<=this.getSaldo() && numero!= this.numero) {
		this.setSaldo(this.getSaldo() - valor);
		System.out.println("O valor tranferido foi: R$"+valor+" para a conta "+ numero);
	}else {
		System.out.println("O valor para transferir não pode ser maior que o saldo atual");

	}
}
	

}
